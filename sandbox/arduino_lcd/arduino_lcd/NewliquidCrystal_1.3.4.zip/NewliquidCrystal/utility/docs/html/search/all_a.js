var searchData=
[
  ['pinmode',['pinMode',['../class_i2_c_i_o.html#a53b94274eb6bb68564cf5243323db887',1,'I2CIO::pinMode()'],['../class_s_i2_c_i_o.html#a4ef4fb77ddd3d248be5e0898e33430a3',1,'SI2CIO::pinMode()']]],
  ['portmode',['portMode',['../class_i2_c_i_o.html#a0341888753bc54c4384f5593a870fb34',1,'I2CIO::portMode()'],['../class_s_i2_c_i_o.html#a8e78ee0ee2d1bb12136b5c5a3487512b',1,'SI2CIO::portMode()']]]
];
